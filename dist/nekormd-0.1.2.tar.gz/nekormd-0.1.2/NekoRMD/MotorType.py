from enum import Enum

class MotorType(Enum):
    RMD8x_pro = 1
    OTHER = 2